
import React from 'react';

interface CardProps {
  isFlipped: boolean;
  isLoading: boolean;
  answer: string;
  error: string | null;
  onClick: () => void;
}

const LoadingSpinner: React.FC = () => (
  <div className="flex items-center justify-center h-full">
    <div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin border-yellow-300/80"></div>
  </div>
);

const CardBack: React.FC = () => (
    <div className="absolute w-full h-full bg-slate-800 rounded-2xl backface-hidden flex items-center justify-center p-4 border-2 border-yellow-400/30 shadow-lg shadow-yellow-400/10">
      <div className="w-48 h-48 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center relative">
        <div className="absolute inset-0 rounded-full opacity-30 animate-pulse bg-white"></div>
        <svg xmlns="http://www.w3.org/2000/svg" className="h-24 w-24 text-yellow-200" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.293 2.293a1 1 0 010 1.414l-7 7a1 1 0 01-1.414 0l-7-7A1 1 0 013.707 5.293L6 3m12 0l2.293 2.293a1 1 0 010 1.414l-7 7a1 1 0 01-1.414 0l-7-7A1 1 0 013.707 5.293L6 3m6 12l2.293 2.293a1 1 0 010 1.414l-7 7a1 1 0 01-1.414 0l-7-7a1 1 0 010-1.414L6 15" />
        </svg>
      </div>
    </div>
);

const CardFront: React.FC<{ isLoading: boolean; answer: string; error: string | null }> = ({ isLoading, answer, error }) => (
    <div className="absolute w-full h-full bg-slate-800 rounded-2xl backface-hidden [transform:rotateY(180deg)] flex items-center justify-center p-6 border-2 border-yellow-400/30 shadow-lg shadow-yellow-400/20">
      <div className="text-center">
        {isLoading ? <LoadingSpinner /> : 
         error ? <p className="text-lg text-red-400 font-medium">{error}</p> : 
         <p className="text-xl md:text-2xl text-yellow-100/90 leading-relaxed font-serif">{answer}</p>
        }
      </div>
    </div>
);

export const Card: React.FC<CardProps> = ({ isFlipped, isLoading, answer, error, onClick }) => {
  return (
    <div 
        className="w-[300px] h-[480px] md:w-[350px] md:h-[560px] cursor-pointer group"
        onClick={onClick}
    >
      <div 
        className={`relative w-full h-full transition-transform duration-700 [transform-style:preserve-3d] ${isFlipped ? '[transform:rotateY(180deg)]' : ''}`}
      >
        <CardBack />
        <CardFront isLoading={isLoading} answer={answer} error={error} />
      </div>
    </div>
  );
};

// Custom CSS for backface-visibility
const style = document.createElement('style');
style.innerHTML = `
  .backface-hidden {
    -webkit-backface-visibility: hidden;
    backface-visibility: hidden;
  }
`;
document.head.appendChild(style);

