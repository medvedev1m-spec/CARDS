
import React, { useState, useCallback } from 'react';
import { getMetaphoricalAnswer } from './services/geminiService';
import { Card } from './components/Card';

const App: React.FC = () => {
  const [isFlipped, setIsFlipped] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [answer, setAnswer] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  const handleCardClick = useCallback(async () => {
    if (isLoading) return;

    if (isFlipped) {
      setIsFlipped(false);
      // Allow the card to flip back before clearing the answer
      setTimeout(() => {
        setAnswer('');
        setError(null);
      }, 700);
      return;
    }

    setIsFlipped(true);
    setIsLoading(true);
    setError(null);

    try {
      const generatedAnswer = await getMetaphoricalAnswer();
      setAnswer(generatedAnswer);
    } catch (err) {
      console.error(err);
      const errorMessage = (err instanceof Error) ? err.message : 'Произошла неизвестная ошибка. Попробуйте еще раз.';
      if (errorMessage.includes('API key')) {
          setError('Ошибка: API ключ не предоставлен или недействителен. Убедитесь, что ключ API настроен правильно.');
      } else {
          setError(errorMessage);
      }
      setAnswer(''); // Clear any previous answer
    } finally {
      setIsLoading(false);
    }
  }, [isLoading, isFlipped]);

  return (
    <main className="min-h-screen bg-slate-900 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-indigo-900/50 via-slate-900 to-black text-white flex flex-col items-center justify-center p-4 font-sans perspective-[1000px]">
      <div className="text-center mb-8">
        <h1 className="text-4xl md:text-5xl font-bold text-yellow-200/90 tracking-wider" style={{ fontFamily: "'Cinzel', serif" }}>
          Спроси свою Вселенную
        </h1>
        <p className="text-slate-300 mt-4 text-lg max-w-md mx-auto">
          {isFlipped ? 'Вот что говорит Вселенная...' : 'Сосредоточьтесь на своем вопросе и коснитесь карты, чтобы получить ответ.'}
        </p>
      </div>

      <Card
        isFlipped={isFlipped}
        isLoading={isLoading}
        answer={answer}
        error={error}
        onClick={handleCardClick}
      />
    </main>
  );
};

export default App;
