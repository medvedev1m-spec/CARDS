
import { GoogleGenAI } from "@google/genai";

const getApiKey = (): string => {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
      throw new Error("API key is not available. Please set the API_KEY environment variable.");
    }
    return apiKey;
};

const ai = new GoogleGenAI({ apiKey: getApiKey() });

const model = 'gemini-2.5-flash';

export const getMetaphoricalAnswer = async (): Promise<string> => {
  try {
    const prompt = `Ты — колода метафорических карт 'Вселенная'. Ответь на невысказанный вопрос пользователя. Твой ответ должен быть коротким (1-3 предложения), метафоричным, мудрым и немного загадочным. Он должен давать пищу для размышлений, а не прямой совет. Действуй как оракул. Не задавай вопросов. Просто дай ответ.`;

    const response = await ai.models.generateContent({
        model: model,
        contents: prompt,
    });
    
    return response.text.trim();

  } catch (error) {
    console.error("Error generating content from Gemini API:", error);
    throw new Error("Не удалось получить ответ от Вселенной. Пожалуйста, попробуйте еще раз позже.");
  }
};
